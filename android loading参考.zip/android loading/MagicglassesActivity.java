package com.mxr.dreambook.activity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.mxr.dreambook.R;
import com.mxr.dreambook.constant.MXRConstant;
import com.mxr.dreambook.model.BaseEvent;
import com.mxr.dreambook.model.Environment;
import com.mxr.dreambook.model.Marker;
import com.mxr.dreambook.model.Page;
import com.mxr.dreambook.model.Size;
import com.mxr.dreambook.util.ARUtil;
import com.mxr.dreambook.util.DataStatistics;
import com.mxr.dreambook.util.MethodUtil;
import com.mxr.dreambook.util.PreferenceKit;
import com.mxr.dreambook.util.XMLParse;
import com.mxr.dreambook.util.server.ConnectServerFacade;
import com.mxr.dreambook.view.dialog.ARDialog;
import com.mxr.dreambook.view.dialog.ARTipsDialog;
import com.mxr.dreambook.view.dialog.ModelLoadingDialog;
import com.mxr.dreambook.view.widget.UnityLayer;
import com.umeng.analytics.MobclickAgent;
import com.unity3d.player.UnityPlayer;

import org.json.JSONException;
import org.json.JSONStringer;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by Administrator on 2015/8/11.
 */
public class MagicglassesActivity extends FragmentActivity implements View.OnClickListener {
    //当前显示的对话框
    private Dialog mCurrentDialog;
    private View mView;
    private ViewGroup mContentView;
    private ImageView mBtnBack;
    private ImageView mBtnPhone;
    private ImageView mBtnEye;
    private ImageView mBtnSwitch;

    private UnityLayer mUnityPlayer;

    //重力加速度参数
    private  SensorManager mSensorManager;
    private double mZvertical = 2;
    private final double mGravity = -9.80665;

    private String mModelPath;
    private String mShaderPath;

    private boolean mIsUnityCallSucceed = false;
    private boolean canShowNaviBar=true;
    private Timer mNaviTimer=null;
    private ProgressBar mProgressBarLoading;
    private int mCurrentProgress = 0;

    protected long mStartReadingTime = 0;
    private final static int LOADING_PROGRESS = 3;
    private final int LOADING_PROGRESS_DELAY = 500;
    private int mDelay = 1;

    private String mBookGiud;
    private String mBookPath;

    protected HashMap<String, BaseEvent> mEvents;
    private ArrayList<Integer> mPageIndexs;
    private Size mMarkerSize;
    protected ArrayList<Marker> mMarkers;
    private MXRConstant.BOOK_MODE_TYPE mBookModeType = MXRConstant.BOOK_MODE_TYPE.UN_KNOW;
    private HashMap<String, String> mResources;
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if(msg != null) {
                switch (msg.what) {
                    case LOADING_PROGRESS :
                        mCurrentProgress += 10;
                        mProgressBarLoading.setProgress(mCurrentProgress);
                        if (mCurrentProgress <= 50) {
                            mDelay += 1;
                            mHandler.sendEmptyMessageDelayed(LOADING_PROGRESS, LOADING_PROGRESS_DELAY * mDelay);
                        } else if (mCurrentProgress > 50 && mCurrentProgress <100) {
                            mDelay += 1.1;
                            mHandler.sendEmptyMessageDelayed(LOADING_PROGRESS, LOADING_PROGRESS_DELAY * mDelay);
                        }
                        break;
                }
            }
        }
    };
    /**

     *  重力监听

     */
    final SensorEventListener mAccelerometerListener = new SensorEventListener(){
        //复写onSensorChanged方法
        public void onSensorChanged(SensorEvent sensorEvent){
            if(sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER){
                //获取z轴重力值
                mZvertical = sensorEvent.values[2];
            }
        }

        //复写onAccuracyChanged方法
        public void onAccuracyChanged(Sensor sensor , int accuracy){
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_magicglasses);
        mStartReadingTime = System.currentTimeMillis();

        getData();
        showLoadingDialog();
        initUI();
        initUserAcceleration();
        ARUtil.getInstance().saveIsReading(this, true);
        initARView();
        initUnity();
        DataStatistics.getInstance(this).statisticsOpenBook(getGUID());
    }

    @Override
    public void onResume() {
        MobclickAgent.onResume(this);
        if ((mUnityPlayer != null) ) {
            mUnityPlayer.resume();
        }
        super.onResume();
    }

    @Override
    public void onPause() {
        MobclickAgent.onPause(this);
        if((mUnityPlayer != null) ) {
            mUnityPlayer.pause();
        }
        super.onPause();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if((mUnityPlayer != null) ) {
            mUnityPlayer.configurationChanged(newConfig);
        }

        if ((newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) && (mCurrentDialog != null)) {
            int mScreenWidth = getWindow().getWindowManager().getDefaultDisplay().getWidth();
            int mScreenHeight = getWindow().getWindowManager().getDefaultDisplay().getHeight();

            // 还原一开始的状态
            mView.setLayoutParams(new FrameLayout.LayoutParams(mScreenWidth, mScreenHeight));
            mView.setTranslationX(0);
            mView.setTranslationY(0);
            mView.setRotation(0);
            mView.invalidate();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        long duration = System.currentTimeMillis() - mStartReadingTime;
        ConnectServerFacade.getInstance().addBookDurationData(this, mBookGiud, Math.round(duration / 1000f));
        dismissCurrentDialog();
        ARUtil.getInstance().saveIsReading(this, false);
    }

    private void initUI() {
        mContentView = (ViewGroup) findViewById(R.id.content_view);
        mBtnBack = (ImageView) findViewById(R.id.back);
        mBtnPhone = (ImageView) findViewById(R.id.phone);
        mBtnEye = (ImageView) findViewById(R.id.eye);
        mBtnSwitch = (ImageView) findViewById(R.id.switch_status);

        mBtnBack.setOnClickListener(this);
        mBtnPhone.setOnClickListener(this);
        mBtnEye.setOnClickListener(this);
    }

    private void checkFile() {
        String configPath = mBookPath + MXRConstant.XML_PATH;
        File configFile = new File(configPath);
        if (!configFile.exists()) {
            downloadErrorOnUIThread();
            return;
        }
        ArrayList<Marker> markers = XMLParse.getInstance().getMarkers();
        for (Marker marker : markers) {
            File file = new File(mBookPath + "/" + marker.getMarkerID());
            if (!file.exists() || !file.isDirectory()) {
                downloadErrorOnUIThread();
                return;
            }
        }
    }

    private void downloadErrorOnUIThread() {
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                downloadError();
            }
        });
    }

    private void downloadError() {
        MethodUtil.getInstance().showToast(this, getString(R.string.download_error), 3000);
        if (mBookGiud != null) {
            MethodUtil.getInstance().enableRedownloadBook(this, mBookGiud);
        }
        // 3秒后退出整个在线、离线界面.
        mContentView.postDelayed(new Runnable() {
            @Override
            public void run() {
                MagicglassesActivity.this.finish();
            }
        }, 3000);
    }

    /**

     * 初始化AR视图

     */
    private void initARView() {
        mUnityPlayer = new UnityLayer(this);
        if (mUnityPlayer.getSettings().getBoolean("hide_status_bar", true)) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
        int glesMode = mUnityPlayer.getSettings().getInt("gles_mode", 1);
        boolean trueColor8888 = false;
        mUnityPlayer.init(glesMode, trueColor8888);
        View playerView = mUnityPlayer.getView();
        mContentView.addView(playerView);
        playerView.requestFocus();
        mUnityPlayer.windowFocusChanged(true);
    }

    /**

     * 初始化重力加速度

     */
    private void initUserAcceleration(){
        //创建一个SensorManager来获取系统的传感器服务

        mSensorManager = (SensorManager)getSystemService(Context.SENSOR_SERVICE);

        //选取加速度感应器
        int sensorType = Sensor.TYPE_ACCELEROMETER;
        mSensorManager.registerListener(mAccelerometerListener, mSensorManager.getDefaultSensor(sensorType), SensorManager.SENSOR_DELAY_NORMAL);
        mSensorManager.registerListener(mAccelerometerListener, mSensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE), SensorManager.SENSOR_DELAY_NORMAL);
        mSensorManager.registerListener(mAccelerometerListener, mSensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY), SensorManager.SENSOR_DELAY_NORMAL);
    }

    private void getData() {
        Intent intent = getIntent();
        if(intent != null) {
            mModelPath = intent.getStringExtra(MXRConstant.MODEL_PATH);
            mBookGiud = intent.getStringExtra(MXRConstant.GUID);
            mBookPath = ARUtil.getInstance().getBookAbsolutePath(mBookGiud);
            mShaderPath = mBookPath + "/" + mBookGiud + ".txt";
        }
    }

    private void initUnity(){
        LoadingDataThread thread = new LoadingDataThread();
        thread.setDaemon(true);
        thread.start();
    }

    /**

     * 显示模型加载的对话框

     */
    private void showModelLoadingDialog() {
        dismissCurrentDialog();
        mCurrentDialog = new ModelLoadingDialog(this);
        mCurrentDialog.show();
    }

    public void showLoadingDialog() {
        if (mCurrentDialog == null) {
            mCurrentDialog = new ARDialog(this);
            mView = LayoutInflater.from(this).inflate(R.layout.snap_dialog_book_loading_layout, null);
            mCurrentDialog.setContentView(mView);
            mView.post(new Runnable() {
                public void run() {
                    int mScreenWidth = getWindow().getWindowManager().getDefaultDisplay().getWidth();
                    int mScreenHeight = getWindow().getWindowManager().getDefaultDisplay().getHeight();

                    mView.setLayoutParams(new FrameLayout.LayoutParams(mScreenHeight, mScreenWidth));
                    mView.setTranslationX(-(mScreenHeight - mScreenWidth) / 2);
                    mView.setTranslationY((mScreenHeight - mScreenWidth) / 2);
                    mView.setRotation(90);
                    mView.invalidate();
                    mView.setVisibility(View.VISIBLE);
                }
            });

            View loadingView = mView.findViewById(R.id.iv_loading);
            ARUtil.getInstance().startAnimDrawable(loadingView);
            mProgressBarLoading = (ProgressBar) mView.findViewById(R.id.iv_loading_plane);
            mProgressBarLoading.setVisibility(View.VISIBLE);
            mHandler.sendEmptyMessageDelayed(LOADING_PROGRESS, LOADING_PROGRESS_DELAY);
        } else if (mCurrentDialog.isShowing()) {
            return;
        }
        mCurrentDialog.setCancelable(false);
        mCurrentDialog.setCanceledOnTouchOutside(false);
        mCurrentDialog.show();
    }

    public void showBackDialog(){
        if (mCurrentDialog == null) {
            mCurrentDialog = new ARDialog(this);
            mView = LayoutInflater.from(this).inflate(R.layout.dialog_book_backloading_layout, null);
            mCurrentDialog.setContentView(mView);
            View loadingView = mView.findViewById(R.id.iv_backloading);
            ARUtil.getInstance().startAnimDrawable(loadingView);
        } else if (mCurrentDialog.isShowing()) {
            return;
        }
        mCurrentDialog.setCancelable(false);
        mCurrentDialog.setCanceledOnTouchOutside(false);
        mCurrentDialog.show();
    }


    ARTipsDialog arTipsDialog;
    public void showHelp(){
        boolean isShow = PreferenceKit.getBoolean(this,MXRConstant.HELP_AR_SHOW,false);
        if(!isShow){
            if(arTipsDialog == null || !arTipsDialog.isShowing()){
                arTipsDialog = new ARTipsDialog(this);
                arTipsDialog.show();
            }
        }
    }

    /**

     * dismiss当前的对话框

     */
    private void dismissCurrentDialog() {
        if ((mCurrentDialog != null) && (mCurrentDialog.isShowing())) {
            mCurrentDialog.dismiss();
        }
        mCurrentDialog = null;
        showHelp();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.back:
                finish();
                break;
            case R.id.phone:
                mBtnPhone.setImageResource(R.drawable.magicglasses_phone);
                mBtnEye.setImageResource(R.drawable.magicglasses_eye_press);
                mBtnSwitch.setImageResource(R.drawable.magicglasses_dibu_you);
                UnityPlayer.UnitySendMessage("Main Camera", "MsgChangeToNormalMode", "");
                stopTimer();
                break;
            case R.id.eye:
                mBtnPhone.setImageResource(R.drawable.magicglasses_phone_press);
                mBtnEye.setImageResource(R.drawable.magicglasses_eye);
                mBtnSwitch.setImageResource(R.drawable.magicglasses_dibu_zuo);
                UnityPlayer.UnitySendMessage("Main Camera", "MsgChangeToGlassMode", "");
                stopTimer();
                break;
            default:
                dismissCurrentDialog();
                break;
        }
    }

    //-------------Unity Interface---------------------
    /**

     * 移除在线加载视图，理论上只调一次，但IOS需要调多次，所有这边Android特别判断

     */
    public void MsgRemoveGameLoadingView() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(!mIsUnityCallSucceed) {
                    //      MsgShow4DModelDetailEvent();
                    mIsUnityCallSucceed = true;
                    dismissCurrentDialog();
                } else {
                    dismissCurrentDialog();
                }
            }
        });
    }

    /**
     * 开始退出，显示退出loading
     */
    public void MsgUnityBackStartBack() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                showBackDialog();
                UnityPlayer.UnitySendMessage("Game", "ResetParameterWhenBack", "");
            }
        });
    }

    /**
     * 退出完成，移除退出loading
     */
    public void MsgUnityBackOk(){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(mUnityPlayer != null) {
                    mUnityPlayer.quit();
                }
            }
        });
        finish();
    }

    /**
     * 显示模型加载视图
     */
    public void MsgShowModelLoadingView() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                showModelLoadingDialog();
            }
        });
    }

    /**

     * 移除模型加载视图

     */
    public void MsgRemoveModelLoadingView() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                dismissCurrentDialog();
            }
        });
    }

    /**
     * 移除在线界面的扫描视图
     */
    public void MsgRemoveScanView() {
    }


    /**
     * 显示在线界面的扫描视图
     */
    public void MsgShowScanView() {
    }


    /**
     * 设置页码
     *
     * @param index
     */
    public void MsgSetCurMarkerIndex(int index) {
    }

    /**

     * UGC按钮点击事件

     *
     * @param btnType
     * @param btnId
     * @param url
     * @param posX
     * @param posY
     */
    public void MsgBtnClick(int btnType,String btnId,String url,float posX, float posY) {
    }

    /**
     * 模型点击事件触发
     * @param colliderID
     * @param colliderName
     */
    public void MsgModelColliderTouchEvent (final String colliderID,final String colliderName) {
    }

    /**
     * 显示训练的对话框
     */
    public void MsgShowTrainMarkerLoading() {
    }

    /**
     * 移除训练的对话框
     */
    public void MsgRemoveTrainMarkerLoading() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                dismissCurrentDialog();
            }
        });
    }

    /**
     * 点击模型之外的区域
     */
    public void MsgClickScreenEvent() {
        MsgShowNavigationBar() ;
    }


    /**
     * 显示4D模型
     */
    public void MsgShow4DModelDetailEvent() {
        if(!TextUtils.isEmpty(mModelPath)) {
            UnityPlayer.UnitySendMessage("Game", "ShowPreviewFourDModelDetailEvent", mModelPath);
            //加载shader文件
            UnityPlayer.UnitySendMessage("Game", "GetModelMatConfig", mShaderPath);
        }
    }

    /**
     * 停止显示4D模型
     */
    public void MsgDestroy4DModel() {
        UnityPlayer.UnitySendMessage("Game", "DestroyFourDModel", "");
    }

    /**
     * 获取重力加速度
     */
    public double MsgGetUserAcceleration(){
        return (double) (mZvertical/mGravity);
    }

    /**
     * 返回这本书是否激活  1表示激活  0表示没有激活
     */
    public int MsgIfActiveThisBook() {
        return 0;

    }

    /**
     * 没有激活则去激活界面
     */
    public void MsgGoToActiveView() {

    }

    /**
     * 当取消激活或成功或失败激活时调用
     */
    public void MsgEnableTrackWhenGame() {

    }

    /**
     * 当程序进入在线的时候必须调用此方法并传入bookGUID
     */
    public void MsgOnLineAndLoadBookMarker() {
        UnityPlayer.UnitySendMessage("Game", "LoadMagicGlass", genPageJsonObject().toString());
        //加载shader文件
        UnityPlayer.UnitySendMessage("Game", "GetModelMatConfig", mShaderPath);
    }

    /**
     * 获取该书籍的guid
     *
     */
    public String getGUID() {
        Intent intent = getIntent();
        if (intent != null) {
            String guid = intent.getStringExtra(MXRConstant.GUID);
            return guid;
        }
        else {
            return "";
        }
    }

    /**
     * 调用Unity接口用于切换横屏
     */
    public void MsgChangeScreenOrientation(){
        UnityPlayer.UnitySendMessage("Main Camera", "changeToLandscape", "");
    }

    /**
     *  Unity调用用于隐藏导航栏
     */
    public void MsgDismissNavigationBar(){
        MagicglassesActivity.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                dismissNavigationBar();
                canShowNaviBar = true;
            }
        });
    }

    /**
     *  Unity调用用于显示导航栏显示
     */
    public void MsgShowNavigationBar(){
        if(canShowNaviBar){
            MagicglassesActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    showNavigationBar();
                    canShowNaviBar=false;
                }
            });
            TimerTask task = new TimerTask(){
                public void run(){
                    MsgDismissNavigationBar();
                    canShowNaviBar=true;
                }
            };
            mNaviTimer = new Timer();
            mNaviTimer.schedule(task, 5000);
        }
    }

    /**
     *  显示导航栏
     */
    public void showNavigationBar(){
        mBtnSwitch.setVisibility(View.VISIBLE);
        mBtnBack.setVisibility(View.VISIBLE);
        mBtnPhone.setVisibility(View.VISIBLE);
        mBtnEye.setVisibility(View.VISIBLE);
    }

    /**
     *  隐藏导航栏
     */
    public void dismissNavigationBar(){
        mBtnSwitch.setVisibility(View.GONE);
        mBtnBack.setVisibility(View.GONE);
        mBtnPhone.setVisibility(View.GONE);
        mBtnEye.setVisibility(View.GONE);
    }

    /**
     *  停止定时器
     */
    public void stopTimer() {
        canShowNaviBar=false;
        if (mNaviTimer != null) {
            mNaviTimer.cancel();
            mNaviTimer = null;
        }
    }

    private class LoadingDataThread extends Thread {
        @Override
        public void run() {
            ARUtil.getInstance().saveIsReading(MagicglassesActivity.this, true);
            XMLParse.getInstance().setContext(MagicglassesActivity.this);
            XMLParse.getInstance().parse(mBookGiud, mBookPath, mBookPath + MXRConstant.XML_PATH);
            mEvents = XMLParse.getInstance().getEvents();
            mPageIndexs = XMLParse.getInstance().getPageIndexs();
            mMarkers = XMLParse.getInstance().getMarkers();
            mMarkerSize = XMLParse.getInstance().getMarkerSize();
            Environment environment = XMLParse.getInstance().getEnvironment();
            if (environment != null) {
                mBookModeType = environment.getBookModeType();
            }
            mResources = XMLParse.getInstance().getResources();
            MsgChangeScreenOrientation();
            MsgOnLineAndLoadBookMarker();
            checkFile();
        }
    }
    public JSONStringer genPageJsonObject() {
        Environment environment = XMLParse.getInstance().getEnvironment();
        List<Marker> allMarkers = new ArrayList<>();
        List<Marker> nonElectronicMarkers = XMLParse.getInstance().getNonElectronicMarkers();
        if (mMarkers != null) {
            allMarkers.addAll(mMarkers);
        }
        if (nonElectronicMarkers != null) {
            allMarkers.addAll(nonElectronicMarkers);
        }
        JSONStringer jsonStringer = new JSONStringer();
        try {
            jsonStringer.object();
            jsonStringer.key("page");
            jsonStringer.object();
            for (Marker marker : allMarkers) {
                Page page = marker.getPage();
                if (page != null) {
                    jsonStringer.key(String.valueOf(page.getPageIndex()));
                    jsonStringer.value(page.getMarkerID());
                }
            }
            jsonStringer.endObject();
            jsonStringer.key("book_id");
            jsonStringer.value(getGUID());
            jsonStringer.key("template_id");
            jsonStringer.value(environment.getTemplateID());
            jsonStringer.key("track_mode");
            jsonStringer.value(environment.getTrackMode());
            jsonStringer.key("book_mode");
            switch (environment.getBookModeType()){
                case NEW_BOOK:
                    jsonStringer.value("1");
                    break;
                case OLD_BOOK:
                default:
                    jsonStringer.value("0");
                    break;
            }
            jsonStringer.endObject();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        allMarkers.clear();
        return jsonStringer;
    }

    @Override
    public void onBackPressed() {
        MsgUnityBackStartBack();
    }


    //是否是流畅模式
    public boolean MsgGetIsSmoothStyle() {
        boolean isSmoothMode = getSharedPreferences(
                MXRConstant.SHAREDPREFERENCES_NAME, MODE_PRIVATE | Context.MODE_MULTI_PROCESS)
                .getBoolean(MXRConstant.IS_SMOOTH_MODE, false);
        return isSmoothMode ;
    }

    public String GetScanOritation() {
        return "Portrait";
    }

    public void MsgIsJoystickGameModel(int type) {
    }

    public void MsgShowToOffLineView(){

    }

    /**
     * 获取unity是否正在显示模型
     *
     * @param type
     */
    public void MsgIsShowModel(int type) {
    }
	
	    // 获取新的公共资源商店根目录
    public String MsgGetResStoreRootPath() {
        return MXRConstant.APP_ROOT_PATH + "DreamCommon";
    }

    public void MsgDisActiveResetButton() {

    }

    //unity使用判断手机版本号 0为
    public int MsgIsAndroidSystemMorethanEight(){
        int sdkCode = 0;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            sdkCode = 1;
        }

        return sdkCode;
    }

}
