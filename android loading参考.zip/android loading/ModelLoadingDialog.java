package com.mxr.dreambook.view.dialog;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.mxr.dreambook.R;
import com.mxr.dreambook.util.SafeLoadingUtil;

import java.util.ArrayList;
import java.util.List;

import me.zhanghai.android.materialprogressbar.MaterialProgressBar;

public class ModelLoadingDialog extends Dialog {
	
	private Context mContext = null;
	private String  mLoadingArray;
    private Bitmap mBitmap;
	private int mScreenWidth = 0;
	private int mScreenHeight = 0;
	private ImageView loadImage;
	private MaterialProgressBar mMpbLoad;

	private SafeLoadingUtil mSafeLoadingUtil;

	private int index = 0;
	public ModelLoadingDialog(Context context) {
		super(context, R.style.Model_Dialog_Transparent);
		Window window = getWindow();
		window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
		mScreenWidth = window.getWindowManager().getDefaultDisplay().getWidth();
		mScreenHeight = window.getWindowManager().getDefaultDisplay().getHeight();
		window.setWindowAnimations(R.style.Model_Dialog_Transparent);
		//优化代码:可以点击返回按钮去掉对话框
		setCancelable(true);
		setCanceledOnTouchOutside(false);
		mContext = context;
	}

	public ModelLoadingDialog(Context context,String loadingArray) {
		this(context);
		mLoadingArray = loadingArray;
	}

	public ModelLoadingDialog(Context context, int theme) {
		super(context, theme);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.dialog_model_loading_layout);
		initView();

		setOnDismissListener(new OnDismissListener() {
			@Override
			public void onDismiss(DialogInterface dialog) {
				if (mSafeLoadingUtil != null) {
					mSafeLoadingUtil.stop();
				}
			}
		});
	}

	private void initView() {
		loadImage = (ImageView) findViewById(R.id.iv_loading);
		mMpbLoad = (MaterialProgressBar) findViewById(R.id.mpb_load);
		if(!TextUtils.isEmpty(mLoadingArray)){
			loadImage.setVisibility(View.VISIBLE);
			mMpbLoad.setVisibility(View.GONE);
			RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) loadImage.getLayoutParams();
			params.width = RelativeLayout.LayoutParams.MATCH_PARENT;
			params.height = RelativeLayout.LayoutParams.MATCH_PARENT;
			ViewGroup rootGroup = (ViewGroup) findViewById(R.id.rl_wait);
			rootGroup.updateViewLayout(loadImage, params);
			loadImage.setScaleType(ImageView.ScaleType.CENTER_CROP);

			String[] loadImageIds = mLoadingArray.split(";");
			List<ImageView> imageViews = new ArrayList<>();
			imageViews.add(loadImage);
			mSafeLoadingUtil = new SafeLoadingUtil(imageViews, loadImageIds);
			mSafeLoadingUtil.start();
		}else {
			loadImage.setVisibility(View.GONE);
			mMpbLoad.setVisibility(View.VISIBLE);
			/*if(Build.VERSION.SDK_INT > Build.VERSION_CODES.ICE_CREAM_SANDWICH_MR1){
				loadImage.setBackground(getContext().getResources().getDrawable(R.drawable.icon_loading_mum));
			}else {
				loadImage.setBackgroundDrawable(getContext().getResources().getDrawable(R.drawable.icon_loading_mum));
			}
			loadImage.startAnimation(AnimationUtils.loadAnimation(mContext, R.anim.rotateloading));*/
		}
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}
}
