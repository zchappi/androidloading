package com.mxr.dreambook.view.dialog;


import com.mxr.dreambook.R;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

public class ARDialog extends Dialog {
	
	public ARDialog(Context context) {
		super(context, R.style.Model_Dialog_Transparent);
		Window window = getWindow();
		window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
		this.setCanceledOnTouchOutside(false);
		this.setCancelable(false);
	}

	public ARDialog(Context context, int theme) {
		super(context, theme);
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

}
